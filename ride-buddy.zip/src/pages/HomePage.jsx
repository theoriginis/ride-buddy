import React from "react";
import {
  CssBaseline,
  AppBar,
  Toolbar,
  Typography,
  Box,
  Button,
  TextField,
  Card,
} from "@mui/material";
import Navbar from "../components/Navbar";
import TripForm from "../components/TripForm";
import RideList from "../components/RideList";

function HomePage() {
  return (
    <Box>
      <Navbar loggedIn={true} /> {/* Navbar stays common across pages */}
      <Box sx={{ display: "flex", justifyContent: "space-around", padding: 4 }}>
        <TripForm />
        <img
          src="/map.jpg"
          alt="Logo"
          style={{
            marginRight: 10,
            borderRadius: "10px",
            width: "30%",
            bgcolor: "#E3E3E3",
            height: "600px",
          }}
        />
        {/* Placeholder for Map */}
        <RideList />
      </Box>
    </Box>
  );
}

export default HomePage;
