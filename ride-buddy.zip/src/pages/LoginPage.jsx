import React from "react";
import {
  CssBaseline,
  AppBar,
  Toolbar,
  Typography,
  Box,
  Button,
  TextField,
  Card,
} from "@mui/material";
import Navbar from "../components/Navbar";
import TripForm from "../components/TripForm";
import RideList from "../components/RideList";
import Introduction from "../components/Introduction";

function LoginPage() {
  return (
    <Box sx={{ height: "100vh" }}>
      <Navbar />
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-around",
          padding: 4,
          backgroundImage: "url('/cab-img.jpg')",
          backgroundRepeat: "no-repeat",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
          backgroundSize: "cover",
          height: "90vh",
        }}
      >
        <Box
          sx={{
            my: 10,
          }}
        >
          <Introduction />
        </Box>
        <Box
          sx={{
            background: "#ffffff99",
            borderRadius: "10px",
            height: "430px",
            mx: 20,
            my: 10,
          }}
        >
          <RideList heading={false} />
        </Box>
      </Box>
    </Box>
  );
}

export default LoginPage;
